const {
    Connection,
    Keypair,
} = require('@solana/web3.js')
const bs58 = require('bs58')

const PRIVATE_KEY = "4oudYWbxs7Z6JJSeVZMNxeaFNFYJa2x5bEFL1zGAxLe6rtxjTCTLwX1tS1CGgVpncNsXEJvRDDT7hEXXipTuLF8Y";

const endpoint = "https://api.testnet.solana.com";
/*
const endpoint = "https://api.mainnet-beta.solana.com";
*/
const NFT_STORAGE_TOKEN = 'd1f99e8c.75bff35211c846f3b5002c08ffd072ee';
const revokeMintBool = true
const revokeFreezeBool = true


let tokenInfo = {
    amount: 669000000,
    decimals: 6,
    metadata: '',
    symbol: 'BIBO', // Symbol
    tokenName: 'Bibo' // Name 
}

let metaDataforToken = {
    "name": tokenInfo.tokenName,
    "symbol": tokenInfo.symbol,
    "image": '',
    "description": `The Only-one Solana Founder`,
    "extensions": {
        "website": "bibo.wtf",
        "twitter": "bibothefounder",
        "telegram": "bibocommunity"
    },
    "tags": ["SOLANA", "MEME", "BIBO"]
}

const connection = new Connection(endpoint);
const myKeyPair = Keypair.fromSecretKey(new Uint8Array(bs58.decode(PRIVATE_KEY)));


module.exports = {
    connection,
    myKeyPair,
    NFT_STORAGE_TOKEN,
    revokeMintBool,
    revokeFreezeBool,
    tokenInfo,
    metaDataforToken
};